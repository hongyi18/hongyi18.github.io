1. Copy everything in your ...\AppData\Roaming\TeXstudio folder.

2. Edit stylesheet.qss with your text editor.
	use "replace" to replace every "C:/Users/Hongyi/AppData/Roaming/TeXstudio/rc/"
	so that "Hongyi"->your user name.

3. In texstudio, select "options > load profile" and choose the file "my.txsprofile".